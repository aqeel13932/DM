rm(list=ls())
setwd('/home/aqeel/Study/DM/HW10/')
train <- read.csv('train.csv',header = TRUE)
cor(train)
module<-lm(data = train,target~connections+foreign_conns+foreign_conns2+ccf+poly(conns_new,4)+poly(time,2)+
             poly(ccf_old,2)+account_age+poly(agegroup,4)+poly(browserID,3)+poly(days,4)+poly(usage1,4)+
             usage2+poly(usage3,4)+poly(usage4,4)+poly(usage5,4)+poly(usage5,4))
summary(module)
test<-read.csv('test.csv',header = TRUE)
head(test[,c(1,2)])
result<-predict(module,test)
output<-cbind(result)
colnames(output)<-c('ID','target')

write.csv(output,file='submit 001')
