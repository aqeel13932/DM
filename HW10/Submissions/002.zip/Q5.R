rm(list=ls())
setwd('/home/aqeel/Study/DM/HW10/')
train <- read.csv('train.csv',header = TRUE)
cor(train)
module<-lm(data = train,target~conns_new+time+ccf_old+agegroup+browserID+days+usage1+usage3+usage4+usage5)
#conns_new       2.989e-02  6.409e-03   4.664 3.12e-06 ***
#  time            1.049e-02  4.122e-03   2.545  0.01093 *  
#  ccf_old         2.466e-01  1.063e-01   2.320  0.02036 *  
 # account_age     2.954e-03  1.506e-02   0.196  0.84450    
#agegroup       -8.500e-02  1.683e-02  -5.051 4.45e-07 ***
 # browserID       2.041e-05  7.075e-06   2.885  0.00392 ** 
  #days            1.744e-02  2.862e-03   6.096 1.11e-09 ***
  #usage1          5.160e-01  9.803e-02   5.264 1.43e-07 ***
#  usage2          2.802e-02  8.367e-02   0.335  0.73776    
#usage3         -4.666e-02  3.515e-03 -13.276  < 2e-16 ***
 # usage4          6.857e+00  1.177e-01  58.278  < 2e-16 ***
#  usage5          1.977e+00  1.001e-01  19.737  < 2e-16 ***
summary(module)
test<-read.csv('test.csv',header = TRUE)
head(test[,c(1,2)])
result<-predict(module,test)
output<-cbind(result)
colnames(output)<-c('ID','target')

write.csv(output,file='submit 001')
